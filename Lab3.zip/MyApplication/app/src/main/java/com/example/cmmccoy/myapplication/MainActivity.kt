package com.example.cmmccoy.myapplication

import android.app.Activity
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {

    val nums = Array<String>(10, {i -> i.toString()})

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter.createFromResource(
                this,
                R.array.planets_array,
                android.R.layout.simple_spinner_item
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            spinner2.adapter = adapter
        }

        spinner3.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, nums)

        spinner1.onItemSelectedListener = this
        spinner2.onItemSelectedListener = this
        spinner3.onItemSelectedListener = this
    }

    override fun onItemSelected(parent: AdapterView<*>, view: View, pos: Int, id: Long) {
        // An item was selected. You can retrieve the selected item using
        when(parent){
            spinner1 -> Toast.makeText(this, parent.getItemAtPosition(pos) as String, Toast.LENGTH_SHORT).show()
            spinner2 -> Toast.makeText(this, parent.getItemAtPosition(pos) as String, Toast.LENGTH_SHORT).show()
            spinner3 -> textView.text = parent.getItemAtPosition(pos) as String
        }


    }

    override fun onNothingSelected(parent: AdapterView<*>) {
        // Another interface callback
    }
}
